import{u,j as e,H as Hero,N as Notice,U as UsersIcon,a3 as HeartHandshakeIcon,p as HandshakeIcon,a4 as MailIcon,O as Overlap,K as Form,P as PhotoBand,F as Faq,g as faqItems,f as Img}from"./index-67cb7f76.js";
/* Get Involved page. Inline icons use the same lucide paths as the rest of the site. */
const Svg=({size:n=22,sw:w=1.8,children:c})=>e.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:n,height:n,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:w,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",focusable:"false",children:c});
const Sprout=()=>e.jsxs(Svg,{children:[e.jsx("path",{d:"M7 20h10"}),e.jsx("path",{d:"M10 20c5.5-2.5.8-6.4 3-10"}),e.jsx("path",{d:"M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"}),e.jsx("path",{d:"M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"})]});
const Earth=()=>e.jsxs(Svg,{children:[e.jsx("path",{d:"M21.54 15H17a2 2 0 0 0-2 2v4.54"}),e.jsx("path",{d:"M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17"}),e.jsx("path",{d:"M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05"}),e.jsx("circle",{cx:12,cy:12,r:10})]});
const Heart=()=>e.jsx(Svg,{children:e.jsx("path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"})});
const Arrow=()=>e.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:18,height:18,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2.25,strokeLinecap:"round",strokeLinejoin:"round",className:"btn-arrow","aria-hidden":"true",focusable:"false",children:[e.jsx("path",{d:"M5 12h14"}),e.jsx("path",{d:"m12 5 7 7-7 7"})]});
const Cta=({href:h,ghost:g,label:l,aria:a})=>e.jsxs("a",{className:g?"btn ghost":"btn",href:h,"aria-label":a,children:[e.jsx("span",{className:"btn-label",children:l}),e.jsx(Arrow,{})]});
const Icon=({Ic,size:n=22})=>e.jsx(Ic,{size:n,strokeWidth:1.8,"aria-hidden":"true",focusable:"false"});

const ways=[
  {id:"member",Ic:UsersIcon,img:"portrait",pos:"center 38%",title:"Become a member",text:"Join the circle of Africans and friends connecting across borders, and be part of what we build together.",cta:"Become a member"},
  {id:"volunteer",Ic:HeartHandshakeIcon,img:"activity",pos:"center 50%",title:"Volunteer",text:"Lend your time and skills to events, content and community care. Every hour makes a gathering warmer.",cta:"Volunteer with us"},
  {id:"partner",Ic:HandshakeIcon,img:"hands",pos:"center 50%",title:"Partner with us",text:"Organisations, businesses and creators: let us explore how we can work together for the community.",cta:"Partner with us"},
  {id:"subscribe",Ic:MailIcon,img:"passports",pos:"center 35%",title:"Subscribe",text:"Hear first about events, stories and opportunities. No spam, and you can leave at any time.",cta:"Subscribe"}
];
const values=[
  [Sprout,"Community empowerment","When people feel seen and supported, they find the confidence to speak up, share what they know and lead."],
  [Earth,"Cultural connection","Language, food, music and stories keep us close to home, wherever life has taken us."],
  [HandshakeIcon,"Shared opportunities","Knowledge, introductions and openings travel further when we pass them on to one another."],
  [Heart,"Positive social impact","Every member, volunteer and partner helps make a warmer welcome for those who arrive after us."]
];
const FormTile=({id:i,Ic:I,title:t,blurb:b,children:c})=>e.jsxs("div",{className:"tile formtile gi-form",id:i,children:[e.jsx("span",{className:"gi-ico gi-ico-sm","aria-hidden":"true",children:e.jsx(Icon,{Ic:I,size:22})}),e.jsx("h3",{children:t}),e.jsx("p",{children:b}),c]});

function GetInvolved(){
  u("/get-involved");
  return e.jsxs(e.Fragment,{children:[
    e.jsxs(Hero,{title:"Find your place in the HomeAFar community",crumb:"Get Involved",eyebrow:"Get involved",lead:"Whether you have an hour, a skill, an organisation or simply curiosity, there is a way to take part. Choose the one that suits you.",img:"strength",pos:"center 50%",mobile:"strength",mobilePos:"center 50%",className:"gi-hero",children:[
      e.jsxs("div",{className:"btn-row",children:[e.jsx(Cta,{href:"#ways",label:"See ways to join"}),e.jsx(Cta,{href:"#subscribe",ghost:!0,label:"Just stay in touch"})]})
    ]}),
    e.jsxs("section",{className:"wrap sec gi-ways-sec",id:"ways",children:[
      e.jsxs("div",{className:"measure",children:[e.jsx("span",{className:"eyebrow",children:"Four ways to belong"}),e.jsx("h2",{children:"There is a place for you here"}),e.jsx("p",{children:"Home is wherever we find each other. Pick the route that feels right today; you can always add another later."})]}),
      e.jsx("div",{className:"grid4 gi-ways",children:ways.map(w=>e.jsxs("article",{className:"tile gi-card",children:[
        e.jsx(Img,{name:w.img,sizes:"(min-width:1000px) 270px, (min-width:560px) 45vw, 92vw",className:"tile-img",style:{objectPosition:w.pos}}),
        e.jsx("span",{className:"gi-ico","aria-hidden":"true",children:e.jsx(Icon,{Ic:w.Ic,size:24})}),
        e.jsx("h3",{children:w.title}),e.jsx("p",{children:w.text}),
        e.jsx(Cta,{href:"#"+w.id,label:w.cta,aria:w.cta+" (go to the form)"})
      ]},w.id))})
    ]}),
    e.jsxs("section",{className:"wrap sec alt gi-forms-sec",id:"join",children:[
      e.jsxs("div",{className:"measure",children:[e.jsx("span",{className:"eyebrow",children:"Join in"}),e.jsx("h2",{children:"Tell us a little about you"}),e.jsx(Notice,{children:"Every form on this page goes straight to the HomeAFar team. We use your details only to reply to you, as described in our privacy notice, and you can ask us to delete them at any time."})]}),
      e.jsxs("div",{className:"grid-forms gi-forms",children:[
        e.jsx(FormTile,{id:"member",Ic:UsersIcon,title:"Become a member",blurb:"Join the community and be part of what we build together.",children:e.jsx(Form,{kind:"membership",askMessage:!1,button:"Express interest",done:"Thank you. We will be in touch about membership."})}),
        e.jsx(FormTile,{id:"volunteer",Ic:HeartHandshakeIcon,title:"Volunteer",blurb:"Lend your time and skills to events, content and community care.",children:e.jsx(Form,{kind:"volunteer",messageLabel:"How would you like to help?",button:"Apply",done:"Thank you. We will review your application."})}),
        e.jsx(FormTile,{id:"partner",Ic:HandshakeIcon,title:"Partner with us",blurb:"Organisations, businesses and creators: let us explore working together.",children:e.jsx(Form,{kind:"partner",messageLabel:"About your organisation and idea",button:"Send inquiry"})})
      ]})
    ]}),
    e.jsx("section",{className:"wrap sec gi-impact",children:e.jsxs("div",{className:"split",children:[
      e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow",children:"Why it matters"}),e.jsx("h2",{children:"Belonging is built together"}),e.jsx("p",{children:"Far from home, small gestures carry weight: a welcome, an introduction, an evening shared. Getting involved is how those moments multiply."}),
        e.jsx("ul",{className:"gi-values",children:values.map(([I,t,d])=>e.jsxs("li",{children:[e.jsx("span",{className:"gi-ico gi-ico-sm","aria-hidden":"true",children:e.jsx(I,{})}),e.jsxs("div",{children:[e.jsx("h3",{children:t}),e.jsx("p",{children:d})]})]},t))})]}),
      e.jsx(Overlap,{main:"team",accent:"chat"})
    ]})}),
    e.jsxs(PhotoBand,{name:"puzzle",pos:"center 50%",align:"left",children:[e.jsx("p",{className:"pb-quote",children:"Every piece matters."}),e.jsx("p",{children:"Members, volunteers and partners each fit something in that nobody else can."})]}),
    e.jsx("section",{className:"wrap sec green gi-subscribe",id:"subscribe",children:e.jsxs("div",{className:"split",children:[
      e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow",children:"Stay in the loop"}),e.jsx("h2",{children:"Subscribe to updates"}),e.jsx("p",{children:"Be first to hear about events, stories and opportunities. No spam, and you can ask us to remove your details at any time."})]}),
      e.jsx("div",{className:"tile",children:e.jsx(Form,{kind:"newsletter",askName:!1,askMessage:!1,button:"Subscribe",done:"You are subscribed. Thank you."})})
    ]})}),
    e.jsx(Faq,{items:faqItems})
  ]});
}
export{GetInvolved as default};
