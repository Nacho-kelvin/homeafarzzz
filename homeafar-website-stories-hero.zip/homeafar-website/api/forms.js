// Receives the site's forms (contact, volunteer, partner, membership,
// newsletter, event_registration) and emails them. No database.
//
// Environment variables (Vercel > Project > Settings > Environment Variables):
//   RESEND_API_KEY   required  API key from https://resend.com
//   FORM_TO_EMAIL    optional  where messages go (default: homeafar26@gmail.com)
//   FORM_FROM_EMAIL  optional  sender, must be on a domain verified in Resend
//                              (default: "HomeAFar <onboarding@resend.dev>", which
//                              Resend only delivers to the account owner's own email)

const FORMS = ['contact', 'volunteer', 'partner', 'membership', 'newsletter', 'event_registration'];
const FIELDS = ['name', 'email', 'category', 'event', 'message'];
const clean = (v, max) => String(v == null ? '' : v).replace(/\r/g, '').trim().slice(0, max);

async function readBody(req) {
  let b = req.body;
  if (b && typeof b === 'object' && !Buffer.isBuffer(b)) return b;
  if (Buffer.isBuffer(b)) b = b.toString('utf8');
  if (typeof b !== 'string') {
    b = await new Promise((resolve, reject) => {
      let d = '';
      req.on('data', (c) => (d += c));
      req.on('end', () => resolve(d));
      req.on('error', reject);
    });
  }
  return Object.fromEntries(new URLSearchParams(b));
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false });
  }
  // Same-origin only: a browser posting from another site is rejected. Requests with no
  // Origin header (curl, server-to-server) are not browser cross-site posts and pass.
  const origin = req.headers && req.headers.origin;
  if (origin) {
    let ok = false;
    try { ok = new URL(origin).host === req.headers.host; } catch {}
    if (!ok) return res.status(403).json({ ok: false });
  }
  let body;
  try {
    body = await readBody(req);
  } catch {
    return res.status(400).json({ ok: false });
  }

  // Honeypot: real visitors leave "website" empty. Pretend success to bots.
  if (clean(body.website, 200)) return res.status(200).json({ ok: true });

  const form = clean(body['form-name'] || body.form_kind, 40);
  if (!FORMS.includes(form)) return res.status(400).json({ ok: false });

  const email = clean(body.email, 200);
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ ok: false });

  const key = process.env.RESEND_API_KEY;
  if (!key) {
    console.error('RESEND_API_KEY is not set; form submission could not be delivered.');
    return res.status(500).json({ ok: false });
  }

  const data = {};
  for (const f of FIELDS) if (body[f] != null) data[f] = clean(body[f], f === 'message' ? 5000 : 200);
  const lines = Object.entries(data).map(([k, v]) => `${k}: ${v}`);
  lines.push(`consent: ${body.consent ? 'yes' : 'no'}`);

  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: process.env.FORM_FROM_EMAIL || 'HomeAFar <onboarding@resend.dev>',
        to: [process.env.FORM_TO_EMAIL || 'homeafar26@gmail.com'],
        reply_to: email,
        subject: `[HomeAFar] ${form.replace('_', ' ')} form`.replace(/[\r\n]/g, ' '),
        text: lines.join('\n'),
      }),
    });
    if (!r.ok) {
      console.error('Resend error', r.status, await r.text().catch(() => ''));
      return res.status(502).json({ ok: false });
    }
    return res.status(200).json({ ok: true });
  } catch (e) {
    console.error('Form delivery failed', e && e.message);
    return res.status(502).json({ ok: false });
  }
};
