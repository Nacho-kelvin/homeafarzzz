# HomeAFar website

Website for HomeAFar, an African-founded community and impact initiative connecting Africans across
borders, starting from Romania and Eastern Europe. Delivered by Nechtech Solutions.

## What is in this package

A ready-to-deploy static website: prerendered HTML pages, the site's JavaScript and CSS, optimised photos,
and one Vercel serverless function (`api/forms.js`) that emails form submissions through
[Resend](https://resend.com). There is no database and no build step.

| Path | What it is |
| --- | --- |
| `*.html`, `beyond-the-borders/` | The pages (Home, About, Safe Landing, Tourism, Protection & Justice, Women's Health, Events, Stories, Beyond the Borders, Opportunities, Get Involved, Contact, Privacy, 404) |
| `assets/index-1ec22722.css` | The site stylesheet (colours, typography, layout, responsive rules) |
| `assets/*.js`, fonts | Compiled site code and self-hosted fonts |
| `images/` | Photos as WebP, four widths each (480, 800, 1200, 1600 px) |
| `api/forms.js` | Form email endpoint |
| `listings.json` | Events and opportunities data (currently empty) |
| `vercel.json` | Hosting rules: clean URLs, redirects, security headers, caching |
| `sitemap.xml`, `robots.txt` | Search engine files |
| `scripts/`, `dev-server.mjs` | Local preview server, tests and the site-address tool |

Page text and components are compiled into the JavaScript files and the prerendered HTML. Changing wording
or layout in depth needs the original React source project; styling can be changed in `assets/index-1ec22722.css`.

Page heroes: on phones (up to 699px) every page hero is the same full-width photo at 80svh (clamped 520 to 820px) with the breadcrumb, badge, title and intro over a dark gradient. Look for "Phone hero patterns" in the stylesheet; the focal point of each photo on phones is set there as `.hero .hero-img[src*="name"]{object-position:...}`.

## Requirements

Node.js 18 or newer. No `npm install` is needed: the project has no dependencies.

## Preview locally

```bash
npm run dev          # http://localhost:3000   (PORT=4000 npm run dev to change the port)
```

The local server mirrors production: clean URLs, the 404 page, `/api/listings`, and the form endpoint
`/__forms.html`. To send real email while testing, copy `.env.example` to `.env`, fill in the values and
start with them loaded, for example `node --env-file=.env dev-server.mjs` (Node 20.6+). Without
`RESEND_API_KEY` the form endpoint answers 500 and the site shows its error message, exactly as in
production.

## Test

```bash
npm test
```

Runs 11 dependency-free checks: every route has its HTML file; every page has a title, description,
canonical link, social tags, language and one `<h1>`; every image has `alt`; all local links, scripts,
styles and images resolve; every photo the app registers exists at every width; CSS `url()` references
resolve; the sitemap and `robots.txt` are consistent; JSON files and JSON-LD parse; Vercel rewrites point
at real files; no secrets are committed; and the form API behaves correctly (validation, honeypot, missing
key, provider failure) against a stubbed Resend.

There is no build command, so there is no `npm run build`.

## Deploy to Vercel

1. Push the project to a Git repository and import it in Vercel.
2. Framework preset: **Other**. Leave Build Command and Output Directory empty. The project root is served as-is.
3. Add the environment variables below in *Project > Settings > Environment Variables*, then redeploy.
4. `vercel.json` already sets clean URLs, the form and listings rewrites, `/admin` redirect, security
   headers and long-term caching for `/assets` and `/images`.

### Environment variables

| Name | Required | Purpose |
| --- | --- | --- |
| `RESEND_API_KEY` | yes | Resend API key. Without it, forms return an error and nothing is sent. |
| `FORM_TO_EMAIL` | no | Inbox that receives submissions. Defaults to `homeafar26@gmail.com`. |
| `FORM_FROM_EMAIL` | no | Sender, on a domain verified in Resend. |

Until a domain is verified in Resend, the default sender (`onboarding@resend.dev`) only delivers to the
email address that owns the Resend account. Verify the real domain and set `FORM_FROM_EMAIL` before launch.

## Before launch: set the real domain

Canonical links, Open Graph tags, JSON-LD, `sitemap.xml` and `robots.txt` still point to a Netlify preview
address (`https://majestic-tulumba-87e16b.netlify.app`). Search engines will treat that as the canonical
site, so change it once the production domain is known:

```bash
npm run set-site-url -- https://www.your-domain.com
npm test
```

## Before launch

1. **Set the real domain.** Canonical links, social tags, `sitemap.xml` and `robots.txt` currently use a
   temporary preview address (`https://majestic-tulumba-87e16b.netlify.app`). Run
   `npm run set-site-url -- https://your-domain.com`, then `npm test`.
2. **Verify email sending.** Add `RESEND_API_KEY`, verify the sending domain in Resend and set `FORM_FROM_EMAIL`,
   then submit each form once on the live site and confirm the email arrives.
3. Open the live site on a real phone and check the menu and forms.

## Notes

- `/admin` redirects to the homepage. The unused admin screen and its Supabase client were removed from the bundle.
- The form endpoint uses a honeypot field and rejects cross-site browser posts (Origin must match the host). It has no rate limiting; add one if spam appears.
- `vercel.json` sets a Content-Security-Policy (self-hosted scripts, styles, fonts and images only), `X-Frame-Options: DENY` and a Permissions-Policy. If you add a third-party script, font or embed, extend the CSP.
- **Editing assets:** files in `/assets` are cached for a year (`immutable`). After changing any CSS or JS, give the file a new hash in its name and update every reference (HTML pages and the chunks that import it), otherwise returning visitors keep the old file.

## Responsive layout notes

Phone layouts (up to 699px) are defined in `assets/index-1ec22722.css`; tablet and desktop use the overlay hero and
are unchanged.

- **Home hero** (`.hero-full`): photo behind the text, sized to fill the screen below the sticky header
  (`100svh - header`), with the text anchored high so the silhouettes in the photo stay visible.
- **Inner-page intro** (`.hero`): a compact photo band (`clamp(190px, 52vw, 280px)`), then the brown text panel.
  The round icon badge sits on the seam between the two. The block is defined once, in the
  "Phone hero patterns" section at the end of the stylesheet.
- **Cropping**: each photo's focal point is set per page by `--pos-m` on the `<img>`; the Events photo has an
  extra rule in the same section.
- **Photo sizes**: the phone `<source>` of every inner-page intro declares the band's real size
  (`max(100vw, clamp(190px, 52vw, 280px) x photo ratio)`), so a phone downloads the 1200px file at most
  instead of 1600px. If you change the band height in the CSS, change that expression too: it lives in the
  `<picture>` of each page's HTML, in its `<head>` preload, and in the hero component in `assets/index-*.js`.
  The home hero is full-screen, so it keeps its own larger value.
- **Section rhythm**: `--sec` is the vertical padding of every section (44px on small phones, growing to 100px
  on desktop). The first section after an intro uses a smaller top padding.
- **No sideways scroll**: full-width colour bands use `100vw`, so `main` has `overflow-x: clip`. Do not put
  `overflow-x: hidden` on `<body>`: it breaks the sticky header.
- Tested at 320, 360, 375, 390, 414, 430 and 768px (phones, large phones, tablet) and 1280px (desktop) on every route.

## Photo credits

- Tourism, Kenya and homepage tourism photo (zebras on the savanna): Ron Dauphin, via Unsplash
  (free to use under the Unsplash licence; credit is appreciated but not required).
