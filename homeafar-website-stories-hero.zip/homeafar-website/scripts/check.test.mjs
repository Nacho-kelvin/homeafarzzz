// Integrity + backend tests. No dependencies: runs on Node 18+ with `npm test`.
//
// This project is a prebuilt static site, so these tests check what can actually
// break a deployment: missing files, broken internal links, missing SEO tags,
// invalid JSON config, leaked secrets, and the behaviour of the form API.
import test from "node:test"
import assert from "node:assert/strict"
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs"
import { join, extname } from "node:path"
import { fileURLToPath } from "node:url"
import { createRequire } from "node:module"

const root = fileURLToPath(new URL("..", import.meta.url))
const require = createRequire(import.meta.url)
const read = (p) => readFileSync(join(root, p), "utf8")
const exists = (p) => existsSync(join(root, p.replace(/^\/+/, "")))

const ROUTES = [
  "/", "/about", "/contact", "/events", "/get-involved", "/opportunities", "/privacy",
  "/protection-and-justice", "/safe-landing", "/stories-from-afar", "/tourism-to-africa",
  "/womens-health", "/beyond-the-borders", "/beyond-the-borders/kenya",
]
const fileForRoute = (r) => (r === "/" ? "index.html" : `${r.slice(1)}.html`)
const pageFiles = ROUTES.map(fileForRoute)

function walk(dir, out = []) {
  for (const name of readdirSync(join(root, dir))) {
    if (name === "node_modules" || name === ".git") continue
    const rel = join(dir, name)
    statSync(join(root, rel)).isDirectory() ? walk(rel, out) : out.push(rel)
  }
  return out
}

test("every route has a prerendered HTML file", () => {
  for (const f of [...pageFiles, "404.html"]) assert.ok(exists(f), `missing ${f}`)
})

test("every page has title, description, canonical, social tags and one h1", () => {
  for (const f of pageFiles) {
    const html = read(f)
    assert.match(html, /<title>[^<]{5,}<\/title>/, `${f}: title`)
    assert.match(html, /<meta[^>]+name="description"[^>]+content="[^"]{30,}"/, `${f}: description`)
    assert.match(html, /<link[^>]+rel="canonical"/, `${f}: canonical`)
    assert.match(html, /property="og:title"/, `${f}: og:title`)
    assert.match(html, /property="og:image"/, `${f}: og:image`)
    assert.equal((html.match(/<h1[\s>]/g) || []).length, 1, `${f}: exactly one h1`)
    assert.match(html, /<html[^>]+lang="/, `${f}: html lang`)
  }
})

test("every <img> has an alt attribute", () => {
  for (const f of pageFiles) {
    for (const tag of read(f).match(/<img\b[^>]*>/g) || []) {
      assert.match(tag, /\balt=/, `${f}: image without alt: ${tag.slice(0, 90)}`)
    }
  }
})

test("local links, scripts, styles and images in the HTML resolve", () => {
  const routes = new Set(ROUTES)
  for (const f of [...pageFiles, "404.html"]) {
    const html = read(f)
    const urls = new Set()
    for (const m of html.matchAll(/\b(?:href|src)="(\/[^"#?]*)/g)) urls.add(m[1])
    for (const m of html.matchAll(/\b(?:srcset|imagesrcset)="([^"]+)"/g)) {
      for (const part of m[1].split(",")) urls.add(part.trim().split(/\s+/)[0])
    }
    for (const u of urls) {
      if (!u.startsWith("/") || u.startsWith("//")) continue
      if (u === "/__forms.html" || u.startsWith("/api/")) continue
      const clean = u.replace(/\/$/, "") || "/"
      const ok = routes.has(clean) || exists(u)
      assert.ok(ok, `${f}: broken local reference ${u}`)
    }
  }
})

test("every photo registered in the app bundle exists at every listed width", () => {
  const registry = /F\("([^"]+)","([^"]+)",\[([0-9,]+)\]/g
  let checked = 0
  for (const bundle of readdirSync(join(root, "assets")).filter((n) => n.endsWith(".js"))) {
    for (const m of read(`assets/${bundle}`).matchAll(registry)) {
      for (const w of m[3].split(",")) {
        assert.ok(exists(`images/${m[1]}/${m[2]}-${w}.webp`), `${bundle}: missing images/${m[1]}/${m[2]}-${w}.webp`)
        checked++
      }
    }
  }
  assert.ok(checked > 50, "expected to find the photo registry")
})

test("CSS url() references resolve", () => {
  for (const css of readdirSync(join(root, "assets")).filter((n) => n.endsWith(".css"))) {
    for (const m of read(`assets/${css}`).matchAll(/url\((?:"|')?(\/[^)"'?#]+)/g)) {
      assert.ok(exists(m[1]), `${css}: missing ${m[1]}`)
    }
  }
})

test("sitemap lists only real routes and robots.txt points to it", () => {
  const locs = [...read("sitemap.xml").matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => new URL(m[1]).pathname.replace(/\/$/, "") || "/")
  assert.ok(locs.length >= 10)
  for (const p of locs) assert.ok(ROUTES.includes(p), `sitemap lists unknown route ${p}`)
  assert.match(read("robots.txt"), /Sitemap:\s*https?:\/\//i)
})

test("JSON files and JSON-LD blocks are valid", () => {
  for (const f of ["vercel.json", "listings.json", "package.json"]) JSON.parse(read(f))
  for (const f of pageFiles) {
    for (const m of read(f).matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)) {
      assert.doesNotThrow(() => JSON.parse(m[1]), `${f}: invalid JSON-LD`)
    }
  }
})

test("vercel.json rewrites point at files that exist", () => {
  const { rewrites } = JSON.parse(read("vercel.json"))
  for (const r of rewrites) {
    const dest = r.destination.replace(/^\//, "")
    assert.ok(exists(dest) || exists(`${dest}.js`), `rewrite target missing: ${r.destination}`)
  }
})

test("no secrets are committed", () => {
  const patterns = [/re_[A-Za-z0-9]{20,}/, /sk-[A-Za-z0-9]{20,}/, /eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}/]
  const textExt = new Set([".js", ".mjs", ".json", ".html", ".css", ".md", ".txt", ".xml", ".example", ""])
  for (const f of walk(".")) {
    if (f.startsWith("images") || f.startsWith(".git")) continue
    if (!textExt.has(extname(f)) && !f.endsWith(".env.example")) continue
    const text = read(f)
    for (const p of patterns) assert.ok(!p.test(text), `possible secret in ${f} (${p})`)
  }
  assert.ok(!exists(".env"), ".env must not be shipped")
})

// ---- Form API (api/forms.js) with a stubbed Resend call --------------------

function call(handler, { method = "POST", body = {} } = {}) {
  return new Promise((resolve) => {
    const res = {
      statusCode: 200,
      headers: {},
      setHeader(k, v) { this.headers[k] = v },
      status(c) { this.statusCode = c; return this },
      json(d) { resolve({ status: this.statusCode, body: d, headers: this.headers }) },
    }
    handler({ method, body }, res)
  })
}

test("form API behaves correctly", async (t) => {
  const handler = require("../api/forms.js")
  const realFetch = globalThis.fetch
  const realKey = process.env.RESEND_API_KEY
  const realError = console.error
  console.error = () => {}
  t.after(() => {
    globalThis.fetch = realFetch
    console.error = realError
    if (realKey === undefined) delete process.env.RESEND_API_KEY
    else process.env.RESEND_API_KEY = realKey
  })
  const valid = { "form-name": "contact", name: "Ada", email: "ada@example.com", message: "Hello", consent: "on" }
  let sent = []
  globalThis.fetch = async (url, opts) => { sent.push({ url, opts }); return { ok: true, status: 200, text: async () => "" } }

  assert.equal((await call(handler, { method: "GET" })).status, 405, "GET rejected")
  assert.equal((await call(handler, { body: { ...valid, "form-name": "nope" } })).status, 400, "unknown form rejected")
  assert.equal((await call(handler, { body: { ...valid, email: "not-an-email" } })).status, 400, "bad email rejected")

  delete process.env.RESEND_API_KEY
  assert.equal((await call(handler, { body: valid })).status, 500, "missing API key is reported, not hidden")

  process.env.RESEND_API_KEY = "test-key"
  sent = []
  assert.equal((await call(handler, { body: { ...valid, website: "http://spam" } })).status, 200, "honeypot answers 200")
  assert.equal(sent.length, 0, "honeypot must not send email")

  const ok = await call(handler, { body: valid })
  assert.equal(ok.status, 200)
  assert.equal(sent.length, 1)
  assert.equal(sent[0].url, "https://api.resend.com/emails")
  const payload = JSON.parse(sent[0].opts.body)
  assert.equal(payload.reply_to, "ada@example.com")
  assert.match(payload.text, /message: Hello/)

  const crlf = await call(handler, { body: { ...valid, "form-name": "newsletter" } })
  assert.equal(crlf.status, 200)
  assert.ok(!/[\r\n]/.test(JSON.parse(sent.at(-1).opts.body).subject), "subject has no line breaks")

  globalThis.fetch = async () => ({ ok: false, status: 403, text: async () => "denied" })
  assert.equal((await call(handler, { body: valid })).status, 502, "provider rejection surfaces as 502")
  globalThis.fetch = async () => { throw new Error("network down") }
  assert.equal((await call(handler, { body: valid })).status, 502, "network failure surfaces as 502")
})

test("removed admin code is gone and nothing references it", () => {
  const files = walk("assets").filter((f) => /\.(js|css)$/.test(f))
  for (const f of files) assert.doesNotMatch(read(f), /admin-[a-z0-9_]+\.(js|css)|main-[a-z0-9]+\.js|\/api\/admin/, `${f} references removed admin code`)
  assert.ok(!files.some((f) => /admin-|main-/.test(f)), "admin/main chunks should not ship")
})

test("security headers are configured", () => {
  const h = JSON.parse(read("vercel.json")).headers[0].headers.map((x) => x.key)
  for (const k of ["Content-Security-Policy", "X-Frame-Options", "Permissions-Policy", "X-Content-Type-Options"]) assert.ok(h.includes(k), k)
})

test("form API rejects cross-site browser posts", async () => {
  const handler = require("../api/forms.js")
  const res = { code: 0, status(c) { this.code = c; return this }, json() { return this }, setHeader() {} }
  await handler({ method: "POST", headers: { origin: "https://evil.example", host: "homeafar.example" }, body: { "form-name": "contact", email: "a@b.co" } }, res)
  assert.equal(res.code, 403)
})
