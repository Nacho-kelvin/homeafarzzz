// Switch the site's public address everywhere it is hard-coded
// (canonical links, Open Graph tags, JSON-LD, sitemap, robots.txt and the JS bundles).
//
//   npm run set-site-url -- https://www.example.org
//
// Safe to re-run: it detects the current address from robots.txt.
import { readFileSync, writeFileSync, readdirSync, statSync } from "node:fs"
import { join, extname } from "node:path"
import { fileURLToPath } from "node:url"

const root = fileURLToPath(new URL("..", import.meta.url))
const target = (process.argv[2] || "").replace(/\/+$/, "")
if (!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}$/i.test(target)) {
  console.error("Usage: npm run set-site-url -- https://your-domain.com   (https, no path)")
  process.exit(1)
}
const current = (readFileSync(join(root, "robots.txt"), "utf8").match(/Sitemap:\s*(https?:\/\/[^/\s]+)/i) || [])[1]
if (!current) {
  console.error("Could not detect the current address from robots.txt")
  process.exit(1)
}
if (current === target) {
  console.log(`Already set to ${target}`)
  process.exit(0)
}

const exts = new Set([".html", ".xml", ".txt", ".js", ".json"])
let files = 0
let hits = 0
const walk = (dir) => {
  for (const name of readdirSync(join(root, dir))) {
    if (["node_modules", ".git", "images", "scripts"].includes(name)) continue
    const rel = join(dir, name)
    if (statSync(join(root, rel)).isDirectory()) walk(rel)
    else if (exts.has(extname(name)) && name !== "package.json") {
      const text = readFileSync(join(root, rel), "utf8")
      if (!text.includes(current)) continue
      hits += text.split(current).length - 1
      writeFileSync(join(root, rel), text.split(current).join(target))
      files++
    }
  }
}
walk(".")
console.log(`Replaced ${current} -> ${target} (${hits} occurrences in ${files} files).`)
