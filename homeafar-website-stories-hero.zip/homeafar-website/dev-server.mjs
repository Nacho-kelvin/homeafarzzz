import { createServer } from "node:http"
import { createRequire } from "node:module"
import { readFile, stat } from "node:fs/promises"
import { extname, join, normalize, sep } from "node:path"
import { fileURLToPath } from "node:url"

const root = normalize(fileURLToPath(new URL(".", import.meta.url)))
const port = Number(process.env.PORT || 3000)
const require = createRequire(import.meta.url)
const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
}

const pages = new Set([
  "/", "/about", "/contact", "/events", "/get-involved", "/opportunities",
  "/privacy", "/protection-and-justice", "/safe-landing", "/stories-from-afar",
  "/tourism-to-africa", "/womens-health", "/beyond-the-borders", "/beyond-the-borders/kenya",
])

function fileForPath(pathname) {
  if (pathname === "/api/listings") return join(root, "listings.json")
  if (pages.has(pathname)) return join(root, pathname === "/" ? "index.html" : `${pathname.slice(1)}.html`)
  return join(root, pathname.replace(/^\/+/, ""))
}

// Mirrors the Vercel rewrite /__forms.html -> /api/forms so forms can be tested locally.
// Set RESEND_API_KEY (see .env.example) to deliver real email; without it the
// handler answers 500, exactly as it does in production.
async function handleForms(request, response) {
  const handler = require("./api/forms.js")
  response.status = (code) => {
    response.statusCode = code
    return response
  }
  response.json = (data) => {
    response.setHeader("Content-Type", "application/json; charset=utf-8")
    response.end(JSON.stringify(data))
  }
  await handler(request, response)
}

async function sendNotFound(response) {
  let body = "Not found"
  let type = "text/plain; charset=utf-8"
  try {
    body = await readFile(join(root, "404.html"))
    type = types[".html"]
  } catch {}
  response.writeHead(404, { "Content-Type": type })
  response.end(body)
}

createServer(async (request, response) => {
  try {
    const pathname = new URL(request.url, `http://${request.headers.host}`).pathname
    if (pathname === "/admin") {
      response.writeHead(302, { Location: "/" })
      response.end()
      return
    }
    if (pathname === "/__forms.html" || pathname === "/api/forms") return await handleForms(request, response)
    const file = normalize(fileForPath(pathname))
    const relative = file.slice(root.length)
    if (relative.startsWith(`..${sep}`) || relative === "..") {
      response.writeHead(403)
      response.end("Forbidden")
      return
    }
    const info = await stat(file)
    if (!info.isFile()) throw new Error("Not a file")
    const body = await readFile(file)
    const ext = extname(file)
    response.writeHead(200, {
      "Content-Type": types[ext] || "application/octet-stream",
      "Cache-Control": ext === ".html" || ext === ".json" ? "no-cache" : "public, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
    })
    response.end(body)
  } catch {
    await sendNotFound(response)
  }
}).listen(port, "0.0.0.0", () => {
  console.log(`HomeAFar running at http://localhost:${port}`)
})
